extends Node
@export var pipe_scene:PackedScene
var pipe_group=[]
var score

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$HUD/StartButton.show()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	for i in pipe_group:
		i.position.x-=delta*100 #this is just for testing purposes , will remove it later


func game_over() -> void:
	$ScoreTimer.stop()
	$FloorCollisionSound.play()
	$HUD.show_game_over()
	$Player.is_started=false

	
func handle_pipe_collision():
	$PipeCollisionSound.play()

func new_game():
	get_tree().call_group("pipes","queue_free")
	score=0
	$Floor/CollisionShape2D.disabled=false
	$Player.start()
	create_pipes()
	pipe_group=get_tree().get_nodes_in_group("pipes")
	$ScoreTimer.start()
	$HUD.update_score(score)

func create_pipes() -> void:
	for i in range(0,3):
		var x = 300*i
		var y = randi_range(600,605)
		var pipe1=pipe_scene.instantiate()
		pipe1.position=Vector2(x,y)
		var pipe2=pipe_scene.instantiate()
		pipe2.set_flip_y(true)
		pipe2.position=Vector2(x,-10) # when i set the y coordinate to -10 collision works
		#add_child(pipe1,true)
		add_child(pipe2,true)
		

func _on_score_timer_timeout() -> void:
	score+=1
	$HUD.update_score(score)
