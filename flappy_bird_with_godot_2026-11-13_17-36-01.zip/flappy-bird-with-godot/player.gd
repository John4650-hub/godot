extends RigidBody2D
signal floor_collision
signal pipe_collision
const start_pos=Vector2(100,150)
const max_x:int =400
var is_hit:bool
@export var is_started:bool=false
var pressed_start:bool=false
var screen_size


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	freeze=true
	is_hit=false
	hide()
	screen_size=get_viewport_rect().size



# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if is_started:
		if is_hit!=true:
			if Input.is_action_pressed("flap"):
				linear_velocity.x=100
				linear_velocity.y=-200
				$AnimatedSprite2D.play("flap")
				#$WingSound.play()
			else:
				$AnimatedSprite2D.play("down")
		else:
			$AnimatedSprite2D.rotate(deg_to_rad(45))
			$AnimatedSprite2D.play("down")
	else:
		$AnimatedSprite2D.stop()

func start():
	gravity_scale=1.0
	pressed_start=true
	freeze=false
	position=start_pos
	$AnimatedSprite2D.rotation_degrees=0.0
	is_hit=false
	is_started=true
	show()

func _integrate_forces(state: PhysicsDirectBodyState2D) -> void:
	if state.transform.origin.x>max_x:
		state.transform.origin.x=max_x
		state.linear_velocity.x=min(0.0,state.linear_velocity.x)
	if pressed_start:
		state.transform=Transform2D(0.0,start_pos)
		pressed_start=false
	if !is_started:
		state.linear_velocity=Vector2.ZERO
		state.angular_velocity=0.0
		
		
		
func _on_body_entered(body: Node) -> void:
	is_hit=true
	if body.name=="Floor":
		gravity_scale=0
		floor_collision.emit()		
	else:
		pipe_collision.emit()		
	body.get_node("CollisionShape2D").set_deferred("disabled",true)
	
