extends CanvasLayer

signal  start_game

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Message.hide()
	$ScoreLabel.hide()
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func show_game_over():
	$Message.show()
	$MessageTimer.start()
	await $MessageTimer.timeout
	$StartButton.show()

func update_score(score:int):
	$ScoreLabel.text=str(score)

func _on_start_button_pressed() -> void:
	$StartButton.hide()
	$ScoreLabel.show()
	start_game.emit()

func _on_message_timer_timeout() -> void:
	$Message.hide()
