extends StaticBody2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$CollisionShape2D.disabled=false #enable collision

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
func set_flip_y(should_flip:bool)->void:
	if has_node("Sprite2D"):
		$Sprite2D.flip_v=should_flip


func _on_visible_on_screen_enabler_2d_screen_exited() -> void:
	position.x=810
